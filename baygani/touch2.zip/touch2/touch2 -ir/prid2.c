#include "BS83B04A-4.h"
#include "defines.h"

///////////////////////////////////////////////////////



volatile int cod[10]={1,0,1};
volatile int codread[10];
volatile int ncount=0;
volatile long counter3=0;
volatile long counter2=0;
volatile long counter=0;
volatile int m=0 ;
volatile bit q=0;


//////////////////////////////////////////////////////


void __attribute((interrupt(0x04))) int0(void)
{
//	ncount = counter2;
//	counter2=0;
//	//if(ncount>35 && ncount<45)out=~out;
//	if(ncount>55&& ncount<65)out=~out;

	//out=~out;
	//q=~q;
	counter2++;
	counter=0;
	
}




///////////////////////////////////////////////////////





void __attribute((interrupt(0x0C))) timer(void)
{
	
	
	
	/*if(counter<=100){
		
		counter++;
	}*/
	
	
	if(counter2>=400){
		
		out=~out;
		counter2=0;
	}
	
	/*if(counter>=100){
		
		counter2=0;
	}*/
	
	
	
	
	if(m==1){
		if(counter<14000){
		    ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			
			
			
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			
			
			
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			
			
			
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			
			
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			ledir = 0;
			
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			ledir = 1;
			
			
			ledir = 0;
		
		}
		
		if(counter>14000){
			ledir=0;
			
		}
		if(counter>28000){
			counter=0;
			
		}
	}
	
	
	if(q==1){
		ledir = 1;
		ledir = 0;
	}
	
	/*if(counter<14000){
		ledir = 1;
		ledir = 0;
	}
	
	if(counter>14000){
		ledir=0;
		
	}
	if(counter>28000){
		counter=0;
		
	}*/
	
	
	/*if(counter<150){
		
		ledir = 1;
		ledir = 0;
	
	}
	
	if(counter>300)counter=0;*/
	
	
	/*if(cod[m]==1){
		
		if(counter<20){
			ledir = 1;
			ledir = 0;
		}
		if(counter>80){
			counter=0;
			m++;
			if(m>2)m=0;
		}
		
	}
	if(cod[m]==0){
		if(counter<20){
			ledir = 1;
			ledir = 0;
		}
		if(counter>40){
			counter=0;
			m++;
			if(m>2)m=0;
		}
	}*/
	
	
}

////////////////////////////////////////////////////////



void init()
{
	
	
	
	
	
	
	/////////////////////////////////////////////////////////
	
	
	
	_ints1=1;
	_ints0=1;
	_inte=1;
	
	
	/////////////////////////////////////////////////////////
	
	
	
	/*_ws2=1;
	_ws1=0;
	_ws0=0;
	
	_we0=0;
	_we1=1;
	_we2=0;
	_we3=1;
	_we4=0;
	
	_fsyson=1;
	_wrf=1;*/
	
	
	/////////////////////////////////////////////////////////
	
	_ts=0;
    _ton=1;
    
	_tpsc0=0;
    _tpsc1=0;
    _tpsc2=0;
    
    
    _emi=1;
    _hlclk=1;
    
    _tf=1;
    _te=1;
    
    
    
    
	_pac3 = 0;
	_pac5 = 0;
	
	out=0;
}



void main()
{
	init();
	

	while(1)
	{ 	
		GCC_CLRWDT();// reset WDT
		
 	}
} 


