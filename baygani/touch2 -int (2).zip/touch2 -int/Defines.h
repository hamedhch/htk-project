#ifndef _DEFINES_H
#define _DEFINES_H

typedef unsigned long ulong;
typedef unsigned int uint;
typedef unsigned char uchar;
typedef unsigned char bool;
#define true 1
#define false 0 



#define out1		_pa4


#define FINGER_FOCUS_ON		65

#endif
