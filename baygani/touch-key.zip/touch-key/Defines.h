#ifndef _DEFINES_H
#define _DEFINES_H

typedef unsigned long ulong;
typedef unsigned int uint;
typedef unsigned char uchar;
typedef unsigned char bool;
#define true 1
#define false 0 



//#define out1		_pa3
//#define out2		_pa5
//#define out3		_pa1


#define out1		_pa0
#define out2		_pa2
#define out3		_pa4



#define FINGER_FOCUS_ON		800

#define SHORT_DELAY			10000
#define LONG_DELAY          20000

#endif
